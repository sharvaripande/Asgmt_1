cd ..
rm -r data
tar -xf data.tar.gz